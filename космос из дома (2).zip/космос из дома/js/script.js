document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slider img');
    let current = 0;

    function showSlide(n) {
        slides.forEach(s => s.style.display = 'none');
        slides[n].style.display = 'block';
    }

    setInterval(() => {
        current = (current + 1) % slides.length;
        showSlide(current);
    }, 5000);
});